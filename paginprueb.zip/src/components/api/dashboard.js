import axios from 'axios';

export const getStatisticsRequest = async (user) => {
    return await axios.post("http://blackholeapi.us-east-1.elasticbeanstalk.com/api/videogame/statistics", user);
}

export const getTotalStatisticsRequest = async () => {
    return await axios.get("http://blackholeapi.us-east-1.elasticbeanstalk.com/api/videogame/statistics");
}